function askFavoriteFruit() {
    var fruit = prompt("What is your favorite fruit?");
    if (fruit) {
        document.getElementById("fruitResponse").innerText = "I don't like this fruit: " + fruit;
    }
}
document.addEventListener("DOMContentLoaded", function() {
    document.getElementById("welcomeHeader").innerText = "Welcome to my website Professor Ozaydin";
});